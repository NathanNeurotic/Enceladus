<!-- source: https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/history -->
<!-- primary snapshot: 20201112015831  |  11 captures, 3 distinct content version(s) -->
<!-- other distinct versions retained in _versions/history/: 20170629140824, 20250418222756 -->
# history

# **POPS’ History**

______________________________________________________________________________________________________________

ビシバシスペシャル3 / Bishi Bashi Stepchamp 3 (actually a severely cut version of it with only 3 minigames) is the only known PS1 game using an emulator and installed onto the PS2 HDD.  Developed by SCEI and published by KOEI, it was offered to Japanese BB Unit owners, as a DLC, thru the Konami PSBB Channel years ago. It uses an PS1 emulator, originally locked out to work only with its bundled PS1 game and protected with DNAS (content binded to the hard drive and PS2 console at same time, making it work only on that specific PS2 unit it was installed to originally). It  most likely emulates the original Playstation through software emulation. The official Title ID of the package was “SLBB-00001”, and the original partition name was “PP.SLBB-00001” (128MB sized).

The emulator has no official name – it was named “POPS” because that string was found in the disc0 file header (which is the TOC of the RAW source dump). It has few similarities with the PSP Popsloader (undocumented).

- [Chronology – from SLBB-00001 to POPStarter](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/chronology)

- [POC1 demonstration](https://www.youtube.com/watch?v=Afvq_-HXuBo&#38;feature=youtu.be)

- [POC2/POPS-00001 era](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/poc2-pops-00001-era)

- [POPStarter Rev 7](https://www.youtube.com/watch?v=_cTPkU37Scw)

- [POPStarter Rev 9](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/popstarter9)

- [POPStarter Rev 10](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/popstarter10)

- [POPStarter Rev 11](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/popstarter11)

- [POPStarter Rev 12](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/popstarter12)

______________________________________________________________________________________________________________

### [**Index**](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/index)
