<!-- source: https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/automated -->
<!-- primary snapshot: 20240906210815  |  9 captures, 3 distinct content version(s) -->
<!-- other distinct versions retained in _versions/automated/: 20170629130729, 20190411095030 -->
<!-- MERGED: this document losslessly unions all distinct snapshots of the "automated" wiki page. -->
<!-- Snapshot header labels for the same revision differed over time: -->
<!--   2017-06-29 titled the page "LC Cracks, crash fixes & compatibility modes integrated into POPStarter" (changelog form, with per-game fix descriptions + disc counts). -->
<!--   2019-04-11 titled it "Compatibility modes, LibCrypt and various fixes integrated into POPStarter" and labelled the build "POPStarter Revision 13 RIP 06". -->
<!--   2024-09-06 (primary) uses the same title but labels the build "POPStarter Revision 13 Beta 2019/06/05". -->
# automated

# **Compatibility modes, LibCrypt and various fixes integrated into POPStarter**

*(Earliest snapshot 2017-06-29 titled this page "LC Cracks, crash fixes & compatibility modes integrated into POPStarter".)*

______________________________________________________________________________________________________________

These fixes will be automatically applied to your game **as long as you use proper dumps** (for identification).

> **LibCrypt crack caveat (from the 2017-06-29 snapshot):** The LibCrypt cracks are experimental and their reliability hasn't been proven with all the "supported" titles. These were made using **IdentRip v1.02**, which generates "generic" cracks for LibCrypt protected games. The resulting cracks may fail on games that have enhanced protections.
>
> If a POPStarter built-in LibCrypt crack crashes the emulation, prevents you from playing the game or does not work, disable it by patching the POPStarter KELF/ELF with **NO_LC_CRACKS.PPF**, then patch your disc image with a good old PS1 scene crack (you may find some of them in the [Compatibility List](http://www.el_patas.byethost10.com/pops/pops0-9.html) which is maintained by El_Patas for Elotrolado, or at [ConsoleCopyWorld](http://consolecopyworld.com/psx/psx_patches.shtml)).

______________________________________________________________________________________________________________

### *Compatibility modes :*

POPStarter Revision 13 Beta 2019/06/05 auto-activates [compatibility modes](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/compatibility) for the following games *(older snapshots labelled this build "Revision 13 RIP 06")* :

- 40 Winks (SLUS-00874) : $COMPATIBILITY_0×04

- ASCII Entertainment Demo CD (SLUS-90010) : $COMPATIBILITY_0×04

- ATV: Quad Power Racing (SLES-02822) : $COMPATIBILITY_0×04

- ATV: Quad Power Racing (SLUS-01137) : $COMPATIBILITY_0×04

- Action Man: Destruction X (SLES-03083) : $SUBCDSTATUS

- Akumajou Dracula X: Gekka No Yasoukyoku v1.0 (SLPM-86023) : $COMPATIBILITY_0×01

- Akumajou Dracula X: Gekka No Yasoukyoku v1.1 (SLPM-86023) : $COMPATIBILITY_0×01

- Akumajou Dracula X: Gekka No Yasoukyoku v1.2 (SLPM-86023) : $COMPATIBILITY_0×01

- Akumajou Dracula X: Gekka No Yasoukyoku v1.2 (SLPM-86023) : $COMPATIBILITY_0×01
  *(2017 snapshot identifies the second v1.2 as "En by Gemini+Throughhim413 v1.0")*

- Apocalypse (SLES-00460) : $COMPATIBILITY_0×01

- Apocalypse (SLES-00834) : $COMPATIBILITY_0×01

- Apocalypse (SLES-00835, Megera) : $COMPATIBILITY_0×01

- Apocalypse (SLES-01463) : $COMPATIBILITY_0×01

- Apocalypse (SLUS-00373) : $COMPATIBILITY_0×01

- BDFL Manager 2001 (SLES-02977) : $COMPATIBILITY_0×04

- BDFL Manager 2002 (SLES-03605) : $COMPATIBILITY_0×04

- Beat Mania 6th Mix + Core Remix (SLPM-87012) : $COMPATIBILITY_0×01

- Beat Mania 6th Mix + Core Remix (SLPM-87012, R18) : $COMPATIBILITY_0×01

- Bio Hazard v1.1 (SLPS-00222) : $COMPATIBILITY_0×05

- Bio Hazard: Director's Cut (SLPS-00998) : $COMPATIBILITY_0×05

- Bio Hazard: Director's Cut: Dual Shock Ver. (SLPS-01512) : $COMPATIBILITY_0×05

- Bloody Roar II (SCUS-94424) : $COMPATIBILITY_0×04

- Bust A Groove (SCUS-94263) : $COMPATIBILITY_0×04

- Bust A Groove 2 (SLUS-01159) : $COMPATIBILITY_0×04

- Bust A Move 2: Dance Tengoku Mix (SLPM-86219) : $COMPATIBILITY_0×04

- Bust A Move: Dance & Rhythm Action v1.0 (SLPS-01232) : $COMPATIBILITY_0×04

- Bust A Move: Dance & Rhythm Action v1.1 (SLPS-01232) : $COMPATIBILITY_0×04

- Bust-A-Groove (SCES-01313) : $COMPATIBILITY_0×04

- Capcom Generation: Dai 5 Shuu Kakutouka Tachi (SLPS-01725) : $COMPATIBILITY_0×01

- Captain Tsubasa J: Get In The Tomorrow (SLPS-00310) : $COMPATIBILITY_0×04

- Castlevania: Symphony Of The Night (SLES-00524) : $COMPATIBILITY_0×01

- Castlevania: Symphony Of The Night (SLUS-00067) : $COMPATIBILITY_0×01

- Chessmaster II (SLES-02117) : $COMPATIBILITY_0×04

- Chrono Cross (Disc 1) (SLUS-01041) : $COMPATIBILITY_0×04

- Chrono Cross (Disc 2) (SLUS-01080) : $COMPATIBILITY_0×04

- Circuit Breakers (SLUS-00697) : $COMPATIBILITY_0×04

- Clock Tower (SLES-00870) : $COMPATIBILITY_0×04

- Clock Tower (SLES-00871) : $COMPATIBILITY_0×04

- Clock Tower (SLUS-00539) : $COMPATIBILITY_0×04

- Clock Tower 2 (SLPS-00657) : $COMPATIBILITY_0×04

- Clock Tower 2 (Taikenban) (SLPM-80063) : $COMPATIBILITY_0×04

- Clock Tower II: The Struggle Within (SLUS-00695) : $COMPATIBILITY_0×04

- Clock Tower II: The Struggle Within (SLUS-00695, RGR) : $COMPATIBILITY_0×04

- Clock Tower: Ghost Head (SLPS-01290) : $COMPATIBILITY_0×04

- Codename: Tenka (SCUS-94409, Kudos) : $NOVMC1

- Codename: Tenka v1.0 (SCUS-94409) : $NOVMC1

- Colin McRae Rally 2.0 (SLUS-01222) : $CODECACHE_ADDON_0

- Colin McRae Rally 2.0 v1.0 (SLES-02605) : $CODECACHE_ADDON_0

- Colin McRae Rally 2.0 v1.1 (SLES-02605) : $CODECACHE_ADDON_0

- Colony Wars (Disc 1) (SLES-00860) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Colony Wars (Disc 1) (SLES-00861) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Colony Wars (Disc 1) (SLUS-00543) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Colony Wars (Disc 2) (SLES-10860) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Colony Wars (Disc 2) (SLES-10861) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Colony Wars (Disc 2) (SLUS-00554) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Colony Wars (SLED-00091) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Colony Wars: Red Sun (SCES-01924) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Colony Wars: Red Sun (SCES-02621) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Colony Wars: Red Sun (SCES-02623) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Colony Wars: Red Sun (SLUS-00866) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Colony Wars: Vengeance (SLES-01392) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Colony Wars: Vengeance (SLES-01405) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Colony Wars: Vengeance (SLES-01408) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Colony Wars: Vengeance (SLUS-00722) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Cool Boarders (SCES-00568) : $COMPATIBILITY_0×03

- Cool Boarders (SCUS-94356) : $COMPATIBILITY_0×03

- Cool Boarders 2 (SCES-00992) : $COMPATIBILITY_0×03

- Cool Boarders 2 (SCUS-94358) : $COMPATIBILITY_0×03

- Cool Boarders 2: Killing Session (SLPS-00967) : $COMPATIBILITY_0×03

- Critical Blow (SLPS-01044) : $COMPATIBILITY_0×04

- Cybernetic Empire (Disc 1) (SLPS-01912) : $COMPATIBILITY_0×04

- Cybernetic Empire (Disc 2) (SLPS-01913) : $COMPATIBILITY_0×04

- Cybernetic Empire (SLPS-01913, RGR) : $COMPATIBILITY_0×04

- Dance Dance Revolution: Disney's Rave (SLPM-86667) : $COMPATIBILITY_0×06 *(from 2017 snapshot)*

- Dance Dance Revolution: Disney's Rave (SLPM-86667, R18) : $COMPATIBILITY_0×06 *(from 2017 snapshot)*

- Dead Or Alive (SCES-01259) : $COMPATIBILITY_0×04

- Dead Or Alive (SLPS-01289) : $COMPATIBILITY_0×04 $COMPATIBILITY_0×06

- Dead Or Alive (SLUS-00606) : $COMPATIBILITY_0×04

- Die Hard Trilogy (SLES-00445) : $COMPATIBILITY_0×03

- Die Hard Trilogy v1.0 (SLUS-00119) : $COMPATIBILITY_0×03

- Die Hard Trilogy v1.1 (SLUS-00119) : $COMPATIBILITY_0×03

- Disney Fais Ton Histoire!: Mulan (SCES-02004) : $COMPATIBILITY_0×01

- Disney Libro Animato Creativo: Mulan (SCES-02006) : $COMPATIBILITY_0×01

- Disney's Aventura Interactiva: Mulan (SCES-02007) : $COMPATIBILITY_0×01

- Disney's Story Studio: Mulan (SCES-01695) : $COMPATIBILITY_0×01

- Disney's Verhalenstudio: Mulan (SCES-02264) : $COMPATIBILITY_0×01

- Disneys Interaktive Abenteuer: Mulan (SCES-02005) : $COMPATIBILITY_0×01

- DonPachi (SLPS-00548) : $COMPATIBILITY_0×06 *(from 2017 snapshot)*

- Double Dragon (SLPS-00191) : $COMPATIBILITY_0×03

- Dragon Valor (Disc 1) (SCES-01705) : $COMPATIBILITY_0×04

- Dragon Valor (Disc 1) (SCES-02565) : $COMPATIBILITY_0×04

- Dragon Valor (Disc 1) (SCES-02566) : $COMPATIBILITY_0×04

- Dragon Valor (Disc 1) (SCES-02567) : $COMPATIBILITY_0×04

- Dragon Valor (Disc 1) (SCES-02568) : $COMPATIBILITY_0×04

- Dragon Valor (Disc 1) (SLPS-02190) : $COMPATIBILITY_0×04

- Dragon Valor (Disc 1) (SLUS-01092) : $COMPATIBILITY_0×04

- Dragon Valor (Disc 2) (SCES-11705) : $COMPATIBILITY_0×04

- Dragon Valor (Disc 2) (SCES-12565) : $COMPATIBILITY_0×04

- Dragon Valor (Disc 2) (SCES-12566) : $COMPATIBILITY_0×04

- Dragon Valor (Disc 2) (SCES-12567) : $COMPATIBILITY_0×04

- Dragon Valor (Disc 2) (SCES-12568) : $COMPATIBILITY_0×04

- Dragon Valor (Disc 2) (SLPS-02191) : $COMPATIBILITY_0×04

- Dragon Valor (Disc 2) (SLUS-01164) : $COMPATIBILITY_0×04

- Enigma (Disc 1) (SLPS-01351) : $COMPATIBILITY_0×04

- Enigma (Disc 2) (SLPS-01352) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 1) (SLES-02965) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 1) (SLES-02966) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 1) (SLES-02967) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 1) (SLES-02968) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 1) (SLES-02969) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 1) (SLPS-02000) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 1) (SLUS-01251) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 2) (SLES-12965) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 2) (SLES-12966) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 2) (SLES-12967) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 2) (SLES-12968) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 2) (SLES-12969) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 2) (SLPS-02001) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 2) (SLUS-01295) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 3) (SLES-22965) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 3) (SLES-22966) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 3) (SLES-22967) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 3) (SLES-22968) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 3) (SLES-22969) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 3) (SLPS-02002) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 3) (SLUS-01296) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 4) (SLES-32965) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 4) (SLES-32966) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 4) (SLES-32967) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 4) (SLES-32968) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 4) (SLES-32969) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 4) (SLPS-02003) : $COMPATIBILITY_0×04

- Final Fantasy IX (Disc 4) (SLUS-01297) : $COMPATIBILITY_0×04

- Frogger (SLES-00704) : $COMPATIBILITY_0×04

- Frogger (SLUS-00506) : $COMPATIBILITY_0×04

- Future Racer (SLES-03508) : $COMPATIBILITY_0×04
  *(2017 snapshot lists this as "Crash Fix – Compatibility Mode 0×04")*

- Gex 3D: Enter The Gecko (SLES-00596) : $COMPATIBILITY_0×04

- Gran Turismo (PAPX-90026) : $COMPATIBILITY_0×04

- Gran Turismo (SCES-00984) : $COMPATIBILITY_0×04

- Gran Turismo (SCPS-10045) : $COMPATIBILITY_0×04

- Gran Turismo 2 (Arcade Mode) v1.0 (SCUS-94455) : $COMPATIBILITY_0×01 $COMPATIBILITY_0×04

- Gran Turismo 2 (Arcade Mode) v1.1 (SCUS-94455) : $COMPATIBILITY_0×01 $COMPATIBILITY_0×04

- Gran Turismo 2 (Disc 1) (Arcade Mode) (SCES-02380) : $COMPATIBILITY_0×01 $COMPATIBILITY_0×04

- Gran Turismo 2 (Disc 1) (Arcade) (SCPS-10116) : $COMPATIBILITY_0×01 $COMPATIBILITY_0×04

- Gran Turismo 2 (Disc 2) (GT Mode) (SCES-12380) : $COMPATIBILITY_0×01 $COMPATIBILITY_0×04

- Gran Turismo 2 (Disc 2) (Gran Turismo) v1.0 (SCPS-10117) : $COMPATIBILITY_0×01 $COMPATIBILITY_0×04

- Gran Turismo 2 (Disc 2) (Gran Turismo) v1.1 (SCPS-10117) : $COMPATIBILITY_0×01 $COMPATIBILITY_0×04

- Gran Turismo 2 (Simulation Mode) v1.0 (SCUS-94488) : $COMPATIBILITY_0×01 $COMPATIBILITY_0×04

- Gran Turismo 2 (Simulation Mode) v1.1 (SCUS-94488) : $COMPATIBILITY_0×01 $COMPATIBILITY_0×04

- Gran Turismo 2 (Simulation Mode) v1.2 (SCUS-94488) : $COMPATIBILITY_0×01 $COMPATIBILITY_0×04

- Gran Turismo v1.0 (SCUS-94194) : $COMPATIBILITY_0×04

- Gran Turismo v1.1 (SCUS-94194) : $COMPATIBILITY_0×04

- Grandia (Disc 1) (SCUS-94457) : $COMPATIBILITY_0×04

- Grandia (Disc 1) (SLES-02397) : $COMPATIBILITY_0×04

- Grandia (Disc 1) (SLES-02398) : $COMPATIBILITY_0×04

- Grandia (Disc 1) (SLES-02399) : $COMPATIBILITY_0×04

- Grandia (Disc 1) (SLPS-02124) : $COMPATIBILITY_0×04

- Grandia (Disc 2) (SCUS-94465) : $COMPATIBILITY_0×04

- Grandia (Disc 2) (SLES-12397) : $COMPATIBILITY_0×04

- Grandia (Disc 2) (SLES-12398) : $COMPATIBILITY_0×04

- Grandia (Disc 2) (SLES-12399) : $COMPATIBILITY_0×04

- Grandia (Disc 2) (SLPS-02125) : $COMPATIBILITY_0×04

- Grandia: Prologue (Taikenban) (SLPM-80297) : $COMPATIBILITY_0×04

- Jumping Flash! (SCUS-94103) : $COMPATIBILITY_0×01 $COMPATIBILITY_0×04

- Jumping Flash! 2 (SCUS-94108) : $COMPATIBILITY_0×04

- LMA Manager 2001 (SLES-02975) : $COMPATIBILITY_0×04

- LMA Manager 2002 (SLES-03603) : $COMPATIBILITY_0×04

- Legaia Densetsu (SCPS-10059) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Legend Of Legaia (SCES-01752) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Legend Of Legaia (SCES-01944) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Legend Of Legaia (SCES-01945) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Legend Of Legaia (SCES-01946) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Legend Of Legaia (SCES-01947) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Legend Of Legaia (SCUS-94254) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Legend Of Legaia (SCUS-94366) : $COMPATIBILITY_0×02 $COMPATIBILITY_0×04

- Lifeforce Tenka (SLES-00613) : $NOVMC1

- Lifeforce Tenka (SLES-00614) : $NOVMC1

- Lifeforce Tenka (SLES-00615) : $NOVMC1

- Manager De Liga 2001 (SLES-02979) : $COMPATIBILITY_0×04

- Manager De Liga 2002 (SLES-03607) : $COMPATIBILITY_0×04

- Marvel Super Heroes Vs. Street Fighter (SLES-01792) : $COMPATIBILITY_0×01

- Marvel Super Heroes Vs. Street Fighter (SLUS-00793) : $COMPATIBILITY_0×01

- Marvel Super Heroes Vs. Street Fighter: EX Edition (SLPS-01915) : $COMPATIBILITY_0×01

- Marvel Super Heroes Vs. Street Fighter: EX Edition (Taikenban) (SLPM-80376) : $COMPATIBILITY_0×01

- Marvel Vs. Capcom: Clash Of Super Heroes (SLES-02305) : $COMPATIBILITY_0×01

- Marvel Vs. Capcom: Clash Of Super Heroes (SLUS-01059) : $COMPATIBILITY_0×01

- Marvel Vs. Capcom: Clash Of Super Heroes: EX Edition (SLPS-02368) : $COMPATIBILITY_0×01

- MediEvil (SCES-00311) : $COMPATIBILITY_0×01
  *(2017 snapshot lists this as "MediEvil v1.1 (SCES-00311) – LibCrypt Crack – Compatibility Mode 0×01")*

- MediEvil (SCES-01492) : $COMPATIBILITY_0×01

- MediEvil (SCES-01493) : $COMPATIBILITY_0×01

- MediEvil (SCES-01494) : $COMPATIBILITY_0×01

- MediEvil (SCES-01495) : $COMPATIBILITY_0×01

- MediEvil (SCUS-94227) : $COMPATIBILITY_0×01

- Mega Man Legends (SLES-01485) : $COMPATIBILITY_0×04

- Mega Man Legends (SLUS-00603) : $COMPATIBILITY_0×04

- Mizzurna Falls (SLPS-01783) : $COMPATIBILITY_0×04

- Mobil 1 Rally Championship (SLES-02574) : $COMPATIBILITY_0×04

- Mobil 1 Rally Championship (SLUS-01103) : $COMPATIBILITY_0×04

- Muppet RaceMania (SLUS-01237) : $COMPATIBILITY_0×04

- Myst (SCUS-94602) : $COMPATIBILITY_0×04

- Myst (SLES-00218) : $COMPATIBILITY_0×04

- Myst v1.0 (SLPS-00024) : $COMPATIBILITY_0×04

- Myst v1.1 (SLPS-91023) : $COMPATIBILITY_0×04

- N-Gen Racing (SLES-02086) : $COMPATIBILITY_0×04
  *(2017 snapshot lists this as "LibCrypt Crack – Compatibility Mode 0×04")*

- N-Gen Racing (SLUS-01155) : $COMPATIBILITY_0×04

- Need For Speed: V-Rally (SLUS-00590) : $CODECACHE_ADDON_0

- Nightmare Creatures II (SLES-02751) : $COMPATIBILITY_0×04

- Nightmare Creatures II (SLUS-01112) : $COMPATIBILITY_0×04

- PaRappa The Rapper (SCES-00743) : $COMPATIBILITY_0×04

- PaRappa The Rapper (SCUS-94183) : $COMPATIBILITY_0×04

- Pac-Man World (SLUS-00439) : $COMPATIBILITY_0×04

- Parasite Eve II (Disc 1) (SLES-02558) : $COMPATIBILITY_0×04

- Parasite Eve II (Disc 1) (SLES-02559) : $COMPATIBILITY_0×04

- Parasite Eve II (Disc 1) (SLES-02560) : $COMPATIBILITY_0×04

- Parasite Eve II (Disc 1) (SLES-02561) : $COMPATIBILITY_0×04

- Parasite Eve II (Disc 1) (SLES-02562) : $COMPATIBILITY_0×04

- Parasite Eve II (Disc 1) (SLPS-02480) : $COMPATIBILITY_0×04

- Parasite Eve II (Disc 1) (SLUS-01042) : $COMPATIBILITY_0×04

- Parasite Eve II (Disc 2) (SLES-12558) : $COMPATIBILITY_0×04

- Parasite Eve II (Disc 2) (SLES-12559) : $COMPATIBILITY_0×04

- Parasite Eve II (Disc 2) (SLES-12560) : $COMPATIBILITY_0×04

- Parasite Eve II (Disc 2) (SLES-12561) : $COMPATIBILITY_0×04

- Parasite Eve II (Disc 2) (SLES-12562) : $COMPATIBILITY_0×04

- Parasite Eve II (Disc 2) (SLPS-02481) : $COMPATIBILITY_0×04

- Parasite Eve II (Disc 2) (SLUS-01055) : $COMPATIBILITY_0×04

- Pop'n Music (SLPM-87089) : $COMPATIBILITY_0×01

- Porsche Challenge (SCES-00409) : $COMPATIBILITY_0×02

- Porsche Challenge (SCUS-94187) : $COMPATIBILITY_0×02

- Porsche Challenge (SIPS-60016) : $COMPATIBILITY_0×02

- Rapid Racer (SCES-00394) : $COMPATIBILITY_0×04

- Ray Crisis (SLES-02882) : $COMPATIBILITY_0×04

- Raycrisis (SLPM-86450) : $COMPATIBILITY_0×04

- Raycrisis: Series Termination (SLUS-01217) : $COMPATIBILITY_0×04

- Resident Evil (SLES-00200) : $COMPATIBILITY_0×05

- Resident Evil (SLES-00227) : $COMPATIBILITY_0×05

- Resident Evil (SLES-00228) : $COMPATIBILITY_0×05

- Resident Evil (SLUS-00170) : $COMPATIBILITY_0×05

- Resident Evil: Director's Cut (SLES-00969) : $COMPATIBILITY_0×05

- Resident Evil: Director's Cut (SLES-00970) : $COMPATIBILITY_0×05

- Resident Evil: Director's Cut (SLUS-00551) : $COMPATIBILITY_0×05

- Resident Evil: Director's Cut: Dual Shock Ver. (SLUS-00747) : $COMPATIBILITY_0×05

- Rockman Dash: Hagane No Boukenshin (SLPS-01141) : $COMPATIBILITY_0×04

- Silent Hill (SLED-01735) : $COMPATIBILITY_0×04

- Silent Hill (SLES-01514) : $COMPATIBILITY_0×04

- Silent Hill (SLUS-00707) : $COMPATIBILITY_0×04

- Silent Hill v1.0 (SLPM-86192) : $COMPATIBILITY_0×04

- Silent Hill v1.1 (SLPM-86192) : $COMPATIBILITY_0×04

- Sled Storm (SLES-02194) : $COMPATIBILITY_0×04

- Spider-Man (SLES-02886) : $SUBCDSTATUS

- Spider-Man (SLES-02887) : $SUBCDSTATUS

- Spider-Man (SLES-02888) : $SUBCDSTATUS

- Spider-Man (SLES-02889) : $SUBCDSTATUS

- Spider-Man (SLES-02890) : $SUBCDSTATUS

- Spider-Man (SLUS-00875) : $SUBCDSTATUS

- Spyro 2: Gateway To Glimmer (SCES-02104) : $COMPATIBILITY_0×01

- Spyro: Year Of The Dragon v1.0 (SCUS-94467) : $COMPATIBILITY_0×01

- Spyro: Year Of The Dragon v1.1 (SCUS-94467) : $COMPATIBILITY_0×01

- Star Gladiator: Episode 1: Final Crusade (SLES-00495) : $COMPATIBILITY_0×04

- Star Gladiator: Episode 1: Final Crusade (SLPS-00539) : $COMPATIBILITY_0×04

- Star Gladiator: Episode 1: Final Crusade (SLUS-00372) : $COMPATIBILITY_0×04

- Street Fighter Collection 2 (SLES-01721) : $COMPATIBILITY_0×01

- Street Fighter Collection 2 (SLUS-00746) : $COMPATIBILITY_0×01

- Street Fighter EX Plus Alpha (SLES-00939) : $COMPATIBILITY_0×04

- Street Fighter EX Plus Alpha (SLPM-86041) : $COMPATIBILITY_0×04

- Street Fighter EX Plus Alpha (SLUS-00548) : $COMPATIBILITY_0×04

- Strikers 1945 (SLPS-00407) : $COMPATIBILITY_0×04

- Super Puzzle Fighter II Turbo (SLES-00605) : $COMPATIBILITY_0×01

- Super Puzzle Fighter II Turbo (SLUS-00418) : $COMPATIBILITY_0×01

- Syphon Filter (SCES-01910) : $COMPATIBILITY_0×04

- Syphon Filter (SCES-01911) : $COMPATIBILITY_0×04

- Syphon Filter (SCES-01913) : $COMPATIBILITY_0×04

- Syphon Filter (SCES-01914) : $COMPATIBILITY_0×04

- Syphon Filter (SLPS-02216) : $COMPATIBILITY_0×04

- Syphon Filter v1.0 (SCUS-94240) : $COMPATIBILITY_0×04

- Syphon Filter v1.1 (SCUS-94240) : $COMPATIBILITY_0×04

- Team Buddies (SCES-01923) : $COMPATIBILITY_0×04

- Team Buddies (SCES-02986) : $COMPATIBILITY_0×04

- Team Buddies (SLUS-00869) : $COMPATIBILITY_0×04

- Tekken 3 (SCES-01237) : $COMPATIBILITY_0×01

- Tekken 3 (SLUS-00402) : $COMPATIBILITY_0×01

- Tekken 3 v1.0 (SLPS-01300 / SLPS-91202) : $COMPATIBILITY_0×01
  *(2017 snapshot lists this as "Compatibility Mode 0×01 – Compatibility Mode 0×06")*

- Test Drive 4 (SLES-00948) : $COMPATIBILITY_0×04

- Test Drive 4 (SLUS-00487) : $COMPATIBILITY_0×04

- Test Drive 4×4 (SLES-01179) : $COMPATIBILITY_0×04

- Tobal 2 v1.1 (SLPM-86033) : $COMPATIBILITY_0×06 *(from 2017 snapshot)*

- Tobal No.1 (SCUS-94208) : $COMPATIBILITY_0×04

- Tobal No.1 (SLES-00497) : $COMPATIBILITY_0×04

- Tobal No.1 (SLPM-87405 / SLPS-00400) : $COMPATIBILITY_0×04
  *(2017 snapshot lists this as "Compatibility Mode 0×04 – Compatibility Mode 0×06")*

- Tom And Jerry In House Trap (SLES-03181) : $NOPAL

- Turbo Prop Racing (SCUS-94229) : $COMPATIBILITY_0×01
  *(2017 snapshot lists Turbo Prop Racing under Compatibility Mode 0×04)*

- V-Rally: 97 Championship Edition v1.0 (SLES-00250) : $CODECACHE_ADDON_0

- V-Rally: 97 Championship Edition v1.1 (SLES-00250) : $CODECACHE_ADDON_0

- V-Rally: 97 Championship Edition v1.2 (SLES-00250) : $CODECACHE_ADDON_0

- V-Rally: Championship Edition (SLPS-01149 / SLPS-91099) : $CODECACHE_ADDON_0

- Vigilante 8: 2nd Battle (SLPS-02615) : $COMPATIBILITY_0×04

- Vigilante 8: 2nd Offense (SLES-02162) : $COMPATIBILITY_0×04

- Vigilante 8: 2nd Offense (SLUS-00868) : $COMPATIBILITY_0×04

- WWF SmackDown! 2: Know Your Role (SLUS-01234) : $COMPATIBILITY_0×04

- Wild 9 (SLES-01333) : $COMPATIBILITY_0×04

- Wild 9 (SLUS-00425) : $COMPATIBILITY_0×04

- Wildroid 9 (SCPS-10080) : $COMPATIBILITY_0×04

- Wip3out (SCES-01909) : $COMPATIBILITY_0×04

- WipEout 2097 (SLES-00327) : $COMPATIBILITY_0×04

- WipEout 3 (SCPS-10098) : $COMPATIBILITY_0×04

- WipEout 3 (SLUS-00865) : $COMPATIBILITY_0×04

- WipEout 3: Special Edition (SCES-02845) : $COMPATIBILITY_0×04

- Wipeout XL (SCUS-94351) : $COMPATIBILITY_0×04

- Wipeout XL (SIPS-60010) : $COMPATIBILITY_0×04

- X-Men: Children Of The Atom (SLES-00198) : $COMPATIBILITY_0×04

- X-Men: Children Of The Atom (SLUS-00044) : $COMPATIBILITY_0×04

- Zero Divide (SLES-00159) : $COMPATIBILITY_0×04 $SUBCDSTATUS

- Zero Divide (SLPS-00083) : $COMPATIBILITY_0×04 $SUBCDSTATUS

- Zero Divide (SLUS-00183) : $COMPATIBILITY_0×04 $SUBCDSTATUS

______________________________________________________________________________________________________________

### *LibCrypt fixes :*

[LibCrypt](http://wiki.redump.org/index.php?title=PlayStation_1:_LibCrypt_protection) is a protection introduced by SONY to prevent games being used on a mod-chipped system. POPStarter can by-pass this protection for [all known LibCrypt protected games](http://redump.org/special-discs/).

POPStarter Revision 13 Beta 2019/06/05 auto-activates LibCrypt fixes for the following games *(older snapshots labelled this build "Revision 13 RIP 06")* :

- Actua Ice Hockey 2 (SLES-01226)

- Anstoss: Premier Manager (SLES-02563)

- Ape Escape (SCES-01564)

- Ape Escape (SCES-02028)

- Ape Escape (SCES-02029)

- Ape Escape (SCES-02030)

- Ape Escape: La Invasion De Los Monos (SCES-02031)

- Asterix Mega Madness (SLES-03324)

- BDFL Manager 2001 (SLES-02977)

- BDFL Manager 2002 (SLES-03605)

- Barbie: Aventure Equestre (SCES-02366)

- Barbie: Race & Ride (SCES-02365)

- Barbie: Race & Ride (SCES-02367)

- Barbie: Race & Ride (SCES-02368)

- Barbie: Race & Ride (SCES-02369)

- Barbie: Sports Extreme (SCES-02488)

- Barbie: Super Sport (SCES-02489)

- Barbie: Super Sports (SCES-02487)

- Barbie: Super Sports (SCES-02490)

- Barbie: Super Sports (SCES-02491)

- CTR: Crash Team Racing (SCES-02105)

- Canal+ Premier Manager (SLES-02293)

- Crash Bash (SCES-02834)

- Dino Crisis (SLES-02207)

- Dino Crisis (SLES-02208)

- Dino Crisis (SLES-02209)

- Dino Crisis (SLES-02210)

- Dino Crisis (SLES-02211)

- Disney Fais Ton Histoire!: Mulan (SCES-02004)

- Disney Libro Animato Creativo: Mulan (SCES-02006)

- Disney Tarzan (SCES-01516)

- Disney Tarzan (SCES-01519)

- Disney's 102 Dalmatians: Puppies To The Rescue (SLES-03189)

- Disney's 102 Dalmatians: Puppies To The Rescue (SLES-03191)

- Disney's Aventura Interactiva: Mulan (SCES-02007)

- Disney's Story Studio: Mulan (SCES-01695)

- Disney's Tarzan (SCES-01431)

- Disney's Tarzan (SCES-02182)

- Disney's Tarzan (SCES-02185)

- Disney's Verhalenstudio: Mulan (SCES-02264)

- Disneys Interaktive Abenteuer: Mulan (SCES-02005)

- Disneys Tarzan (SCES-01517)

- Disneys Tarzan (SCES-01518)

- EA Sports Superbike 2000 (SLES-02538)

- Eagle One: Harrier Attack (SLES-01715)

- Esto Es Futbol (SCES-01704)

- F1 2000 (SLES-02722)

- F1 2000 (SLES-02723)

- F1 2000 (SLES-02724)

- Final Fantasy VIII (Disc 1) (SLES-02080)

- Final Fantasy VIII (Disc 2) (SLES-12080)

- Final Fantasy VIII (Disc 3) (SLES-22080)

- Final Fantasy VIII (Disc 4) (SLES-32080)

- Final Fantasy VIII (Disc 1) (SLES-02081)

- Final Fantasy VIII (Disc 2) (SLES-12081)

- Final Fantasy VIII (Disc 3) (SLES-22081)

- Final Fantasy VIII (Disc 4) (SLES-32081)

- Final Fantasy VIII (Disc 1) (SLES-02082)

- Final Fantasy VIII (Disc 2) (SLES-12082)

- Final Fantasy VIII (Disc 3) (SLES-22082)

- Final Fantasy VIII (Disc 4) (SLES-32082)

- Final Fantasy VIII (Disc 1) (SLES-02083)

- Final Fantasy VIII (Disc 2) (SLES-12083)

- Final Fantasy VIII (Disc 3) (SLES-22083)

- Final Fantasy VIII (Disc 4) (SLES-32083)

- Final Fantasy VIII (Disc 1) (SLES-02084)

- Final Fantasy VIII (Disc 2) (SLES-12084)

- Final Fantasy VIII (Disc 3) (SLES-22084)

- Final Fantasy VIII (Disc 4) (SLES-32084)

- Final Fantasy IX (Disc 1) (SLES-02965)

- Final Fantasy IX (Disc 2) (SLES-12965)

- Final Fantasy IX (Disc 3) (SLES-22965)

- Final Fantasy IX (Disc 4) (SLES-32965)

- Final Fantasy IX (Disc 1) (SLES-02966)

- Final Fantasy IX (Disc 2) (SLES-12966)

- Final Fantasy IX (Disc 3) (SLES-22966)

- Final Fantasy IX (Disc 4) (SLES-32966)

- Final Fantasy IX (Disc 1) (SLES-02967)

- Final Fantasy IX (Disc 2) (SLES-12967)

- Final Fantasy IX (Disc 3) (SLES-22967)

- Final Fantasy IX (Disc 4) (SLES-32967)

- Final Fantasy IX (Disc 1) (SLES-02968)

- Final Fantasy IX (Disc 2) (SLES-12968)

- Final Fantasy IX (Disc 3) (SLES-22968)

- Final Fantasy IX (Disc 4) (SLES-32968)

- Final Fantasy IX (Disc 1) (SLES-02969)

- Final Fantasy IX (Disc 2) (SLES-12969)

- Final Fantasy IX (Disc 3) (SLES-22969)

- Final Fantasy IX (Disc 4) (SLES-32969)

- Football Manager Campionato 2001 (SLES-02978)

- Football Manager Campionato 2002 (SLES-03606)

- Formula One 99 (SCES-01979)

- Formula One 99 (SCES-02222)

- Frontschweine (SLES-02767)

- Fussball Live (SCES-01702)

- Fussball Manager 2001 (SLES-03062)

- Galerians (Disc 1) (SLES-02328)

- Galerians (Disc 2) (SLES-12328)

- Galerians (Disc 3) (SLES-22328)

- Galerians (Disc 1) (SLES-02329)

- Galerians (Disc 2) (SLES-12329)

- Galerians (Disc 3) (SLES-22329)

- Galerians (Disc 1) (SLES-02330)

- Galerians (Disc 2) (SLES-12330)

- Galerians (Disc 3) (SLES-22330)

- Gekido: Urban Fighters (SLES-01241)

- Hogs Of War (SLES-01041)

- Hogs Of War (SLES-02769)

- Jackie Chan Stuntmaster (SCES-01444)

- LMA Manager 2001 (SLES-02975)

- LMA Manager 2002 (SLES-03603)

- Le Mans 24 Hours (SLES-01362)

- Le Monde Des Bleus (SCES-01701)

- Legacy Of Kain: Soul Reaver (SLES-01301)

- Legacy Of Kain: Soul Reaver (SLES-02024)

- Legacy Of Kain: Soul Reaver (SLES-02025)

- Legacy Of Kain: Soul Reaver (SLES-02026)

- Legacy Of Kain: Soul Reaver (SLES-02027)

- Les Cochons De Guerre (SLES-02766)

- Lucky Luke: Western Fever (SLES-03530)
  *(2017 snapshot notes this as a "Title Specific LibCrypt Crack")*

- Manager De Liga 2001 (SLES-02979)

- Manager De Liga 2002 (SLES-03607)

- Marranos En Guerra (SLES-02768)

- MediEvil (SCES-00311)

- MediEvil (SCES-01492)

- MediEvil (SCES-01493)

- MediEvil (SCES-01494)

- MediEvil (SCES-01495)

- MediEvil 2 (SCES-02544)

- MediEvil 2 (SCES-02545)

- MediEvil 2 (SCES-02546)

- Men In Black: The Series: Crashdown (SLES-03519)

- Men In Black: The Series: Crashdown (SLES-03520)

- Men In Black: The Series: Crashdown (SLES-03521)

- Men In Black: The Series: Crashdown (SLES-03522)

- Men In Black: The Series: Crashdown (SLES-03523)

- Michelin Rally Masters: Race Of Champions (SLES-01545)

- Michelin Rally Masters: Race Of Champions (SLES-02395)

- Mike Tyson Boxing (SLES-02839)

- Mission: Impossible (SLES-01906)

- MoHo (SLES-02830)

- N-Gen Racing (SLES-02086)

- Need For Speed: Porsche 2000 (SLES-02689)

- Need For Speed: Porsche 2000 (SLES-02700)

- OverBlood 2 (Disc 1) (SLES-01880)

- OverBlood 2 (Disc 2) (SLES-11880)

- OverBlood 2 v1.0 (Disc 1) (SLES-01879)

- OverBlood 2 v1.0 (Disc 2) (SLES-11879)

- PGA European Tour Golf (SLES-02061)

- PGA European Tour Golf (SLES-02396)

- Parasite Eve II (Disc 1) (SLES-02558)

- Parasite Eve II (Disc 2) (SLES-12558)

- Parasite Eve II (Disc 1) (SLES-02559)

- Parasite Eve II (Disc 2) (SLES-12559)

- Parasite Eve II (Disc 1) (SLES-02560)

- Parasite Eve II (Disc 2) (SLES-12560)

- Parasite Eve II (Disc 1) (SLES-02561)

- Parasite Eve II (Disc 2) (SLES-12561)

- Parasite Eve II (Disc 1) (SLES-02562)

- Parasite Eve II (Disc 2) (SLES-12562)

- Premier Manager 2000 (SLES-02292)

- Prince Naseem Boxing (SLES-00017)

- RC Revenge (SLES-02824)

- Radikal Bikers (SLES-01943)

- Resident Evil 3: Nemesis (SLES-02529)

- Resident Evil 3: Nemesis (SLES-02530)

- Resident Evil 3: Nemesis (SLES-02531)

- Resident Evil 3: Nemesis (SLES-02532)

- Resident Evil 3: Nemesis (SLES-02533)

- Resident Evil 3: Nemesis (SLES-02698)

- Roger Lemerre: La Selection des Champions (SLES-02976)

- Ronaldo V-Football (SLES-00995)

- Ronaldo V-Football (SLES-02681)

- SaGa Frontier 2 (SLES-02112)

- SaGa Frontier 2 (SLES-02113)

- SaGa Frontier 2 (SLES-02118)

- Sno-Cross Championship Racing (SLES-02763)

- Space Debris (SCES-02290)

- Space Debris (SCES-02430)

- Space Debris (SCES-02431)

- Space Debris (SCES-02432)

- Space Debris (SCES-02433)

- Speed Freaks (SCES-01763)

- Spyro 2: Gateway To Glimmer (SCES-02104)

- Spyro: Year Of The Dragon v1.0 (SCES-02835)

- Spyro: Year Of The Dragon v1.1 (SCES-02835)

- Sydney 2000 (SLES-02857)

- Sydney 2000 (SLES-02858)

- Sydney 2000 (SLES-02859)

- Sydney 2000 (SLES-02860)

- Sydney 2000 (SLES-02861)

- TOCA World Touring Cars (SLES-02572)

- TOCA World Touring Cars (SLES-02573)

- TechnoMage: De Terugkeer Der Eeuwigheid (SLES-03245)

- TechnoMage: Die Rueckkehr Der Ewigkeit (SLES-02831)

- TechnoMage: El Retorno De La Eternidad (SLES-03244)

- TechnoMage: En Quete de L'Eternite (SLES-03242)

- TechnoMage: Return Of Eternity (SLES-03241)

- TechnoMage: Ritorno All'Eternita (SLES-03243)

- The F.A Premier League Manager 2001 (SLES-03061)

- The Italian Job (SLES-03489)

- The Italian Job (SLES-03626)

- The Italian Job (SLES-03648)

- Theme Park World (SLES-02688)

- This Is Football (SCES-01700)

- This Is Football (SCES-01703)

- This Is Football (SCES-01882)

- UEFA Euro 2000 (SLES-02704)

- UEFA Euro 2000 (SLES-02705)

- UEFA Euro 2000 (SLES-02706)

- UEFA Euro 2000 (SLES-02707)

- UEFA Euro 2000 (SLES-02708)

- UEFA Striker (SLES-01733)

- Urban Chaos (SLES-02071)

- Urban Chaos (SLES-02354)

- Urban Chaos (SLES-02355)

- V-Rally: Championship Edition 2 (SLES-01907)

- Vagrant Story (SLES-02754)

- Vagrant Story (SLES-02755)

- Vagrant Story (SLES-02756)

- Walt Disney World Quest: Magical Racing Tour (SLES-02733)

- Wip3out (SCES-01909)

- World Championship Snooker (SLES-02196)

______________________________________________________________________________________________________________

### *Miscellaneous fixes :*

POPStarter Revision 13 Beta 2019/06/05 auto-activates miscellaneous fixes for the following games *(older snapshots labelled this build "Revision 13 RIP 06")* :

- 007: Demain Ne Meurt Jamais (SLES-02375)

- 007: Der Morgen Stirbt Nie (SLES-02376)

- 007: Tomorrow Never Dies (SLES-01324)

- 007: Tomorrow Never Dies (SLPS-02604)

- 007: Tomorrow Never Dies (SLUS-00975)

- Akumajou Dracula X: Gekka No Yasoukyoku v1.0 (SLPM-86023)

- Akumajou Dracula X: Gekka No Yasoukyoku v1.1 (SLPM-86023)

- Akumajou Dracula X: Gekka No Yasoukyoku v1.2 (SLPM-86023)

- Akumajou Dracula X: Gekka No Yasoukyoku v1.2 (SLPM-86023)

- Alundra 2: A New Legend Begins (SLES-02600)

- Alundra 2: A New Legend Begins (SLUS-01017)

- Alundra 2: Der Beginn Einer Neuen Legende (SLES-02602)

- Alundra 2: Mashinka No Nazo (SCPS-10115)

- Alundra 2: Une Legende Est Nee (SLES-02601)

- CTR: Crash Team Racing (SCES-02105)

- CTR: Crash Team Racing (SCUS-94426)

- CTR: Crash Team Racing (SCUS-94459)

- Castlevania: Symphony Of The Night (SLES-00524)

- Castlevania: Symphony Of The Night (SLUS-00067)

- Crash Bandicoot (SCES-00344)

- Crash Bandicoot (SCPS-10031)

- Crash Bandicoot (SCUS-94900)

- Crash Bandicoot Beta (1996-05-11)

- Crash Bandicoot Carnival (SCPS-10140)

- Crash Bandicoot DISK 0012 (04-08-1996)

- Crash Bandicoot Racing (SCPS-10118)
  *(2017 snapshot lists this as "Boot Fix – Load Fix")*

- Crash Bash (SCES-02834)

- Crash Bash (SCUS-94570)

- Cybernetic Empire (Disc 1) (SLPS-01912)

- Cybernetic Empire (Disc 2) (SLPS-01913)

- Cybernetic Empire (SLPS-01913, RGR)

- Destruction Derby 2 (SCUS-94350)

- Destruction Derby 2 (SIPS-60012)

- Destruction Derby 2 (SLES-00299)

- Devil's Deception (SLES-00848)

- Future Racer (SLES-03508)

- Genei Tougi: Shadow Struggle (SLPS-00491)

- Harry Potter And The Chamber Of Secrets (SLES-03972)

- Harry Potter And The Chamber Of Secrets (SLES-03973)

- Harry Potter And The Chamber Of Secrets (SLES-03974)

- Harry Potter And The Chamber Of Secrets (SLUS-01503)

- Harry Potter And The Philosopher's Stone (SLES-03662)

- Harry Potter And The Philosopher's Stone (SLES-03663)

- Harry Potter And The Philosopher's Stone (SLES-03664)

- Harry Potter And The Philosopher's Stone (SLES-03665)

- Harry Potter And The Sorcerer's Stone (SLUS-01415)

- Harry Potter To Kenja No Ishi (SLPS-03355)

- Mega Man Legends (SLUS-00603)

- Ninja: Shadow of Darkness (SLES-00756)

- Ninja: Shadow of Darkness (SLES-00757)

- Ninja: Shadow of Darkness (SLES-00758)

- Ninja: Shadow of Darkness (SLES-01554)

- Ninja: Shadow of Darkness (SLUS-00435)

- Parasite Eve II (Disc 1) (SLES-02558)

- Parasite Eve II (Disc 2) (SLES-12558)

- Parasite Eve II (Disc 1) (SLES-02559)

- Parasite Eve II (Disc 2) (SLES-12559)

- Parasite Eve II (Disc 1) (SLES-02560)

- Parasite Eve II (Disc 2) (SLES-12560)

- Parasite Eve II (Disc 1) (SLES-02561)

- Parasite Eve II (Disc 2) (SLES-12561)

- Parasite Eve II (Disc 1) (SLES-02562)

- Parasite Eve II (Disc 2) (SLES-12562)

- Parasite Eve II (Disc 1) (SLPS-02480)

- Parasite Eve II (Disc 2) (SLPS-02481)

- Parasite Eve II (Disc 1) (SLUS-01042)

- Parasite Eve II (Disc 2) (SLUS-01055)

- Rayman 2: The Great Escape (SLES-02905)

- Rayman 2: The Great Escape (SLES-02906)

- Rayman 2: The Great Escape (SLUS-01235)

- Roadsters (SLES-02326)

- Roadsters (SLUS-01024)

- Super Tokusatsu Taisen 2001 (SLPS-02863)

- Team Buddies (SCES-01923)

- Team Buddies (SCES-02986)

- Team Buddies (SLUS-00869)

- Titan Wars (SLES-00275)

- Tomb Raider (SLES-00024)

- Tomb Raider (SLES-00485)

- Tomb Raider (SLES-00486)

- Tomb Raider 2 (SLPS-01200)

- Tomb Raider Gold (SLUS-90152)

- Tomb Raider II: Starring Lara Croft (Beta 1997-09-30)

- Tomb Raider II: Starring Lara Croft (SLES-00107)

- Tomb Raider II: Starring Lara Croft (SLES-00718)

- Tomb Raider II: Starring Lara Croft (SLES-00719)

- Tomb Raider II: Starring Lara Croft (SLES-00719, Licy)

- Tomb Raider II: Starring Lara Croft (SLES-00720)

- Tomb Raider II: Starring Lara Croft v1.0 (SLUS-00437)

- Tomb Raider II: Starring Lara Croft v1.1 (SLUS-00437)

- Tomb Raider II: Starring Lara Croft v1.2 (SLUS-00437)

- Tomb Raider II: Starring Lara Croft v1.3 (SLUS-00437)

- Tomb Raider v1.0 (SLUS-00152)

- Tomb Raider v1.0 (SLUS-00152, FireCross)

- Tomb Raider v1.1 (SLUS-00152)

- Tomb Raider v1.2 (SLUS-00152)

- Tomb Raider v1.3 (SLUS-00152)

- Tomb Raider v1.4 (SLUS-00152)

- Tomb Raider v1.5 (SLUS-00152)

- Tomb Raider v1.6 (SLUS-00152)

- Tomb Raiders (SLPS-00617)

- Um Jammer Lammy (SCES-01753)

- Um Jammer Lammy (SCPS-18011)

- Um Jammer Lammy (SCUS-94448)

- WipEout (SCUS-94301)

- WipEout (SIPS-60003)

- WipEout v1.0 (SCES-00010)

- WipEout v1.1 (SCES-00010)

- Worms Pinball (SLES-00483)

______________________________________________________________________________________________________________

## Changelog / version history (from the 2017-06-29 snapshot)

*The 2017-06-29 snapshot of this page was a changelog-form document. It records per-game fix descriptions and recognised-disc counts across POPStarter Revision 13 WIP/OBT builds and the WIP 05 public release. The fix entries (Compatibility Mode, LibCrypt Crack, Crash Fix, VSync Fix, Disk Check Fix, Sound Fix, Boot/Load Fix, "2nd VMC is disabled", "Skip Metal Gear Featured Cutscenes", etc.) for that snapshot are preserved below.*

### New fixes integrated into POPStarter Revision 13 since WIP 05
*[According to POPStarter changelogs]*

**——POPStarter Revision 13, WIP 06, OBT 15**

**+540 DISCS** are recognised.

- Parasite Eve II all retail versions – game fix (still unplayable)
- Spyro 2 PAL – game fix (still crashes)

**——POPStarter Revision 13, WIP 06, OBT 14**

**540 DISCS** are recognised (new fixes not listed).

**——POPStarter Revision 13, WIP 06, OBT 13**

**495 DISCS** (+34 Disks) are recognised.

- Alundra 2 – Fix
- ATV: Quad Power Racing (SLES-02822) – Compatibility Mode 0×04
- ATV: Quad Power Racing (SLUS-01137) – Compatibility Mode 0×04
- Crash Bandicoot – Fix
- Crash Team Racing (SCUS-94426) – Sound Fix
- Cybernetic Empire (Disc 1) (SLPS-01912) – Crash Fix
- Cybernetic Empire (Disc 2) (SLPS-01913) – Crash Fix
- Cybernetic Empire (SLPS-01913, RGR) – Crash Fix
- Devil's Deception (SLES-00848) – Crash Fix
- Driver 2 v1.0 (Disc 2) (SLUS-01318) – Disk Check Fix
- Driver 2 v1.1 (Disc 2) (SLUS-01318) – Disk Check Fix
- Driver 2: Back On The Streets (Disc 2) (SLES-12994) – Disk Check Fix
- Driver 2: Back On The Streets (Disc 2) (SLES-12996) – Disk Check Fix
- Driver 2: Back On The Streets (Disc 2) (SLES-12997) – Disk Check Fix
- Driver 2: Back On The Streets v1.0 (Disc 2) (SLES-12993) – Disk Check Fix
- Driver 2: Back On The Streets v1.0 (Disc 2) (SLES-12995) – Disk Check Fix
- Driver 2: Back On The Streets v1.1 (Disc 2) (SLES-12993) – Disk Check Fix
- Driver 2: Back On The Streets v1.1 (Disc 2) (SLES-12995) – Disk Check Fix
- F1 2000 (SLES-02723) – LibCrypt Crack
- Formula One 99 (SCES-02222) – LibCrypt Crack
- Jackie Chan Stuntmaster (SCES-01444) – LibCrypt crack
- Men In Black: The Series: Crashdown (SLES-03523) – LibCrypt Crack
- Metal Gear Solid: Special Missions (SLES-02136) – Disk Check Fix
- OverBlood 2 (Disc 1) (SLES-01880) – LibCrypt Crack
- OverBlood 2 (Disc 2) (SLES-11880) – LibCrypt Crack
- OverBlood 2 v1.0 (Disc 1) (SLES-01879) – LibCrypt Crack
- OverBlood 2 v1.0 (Disc 2) (SLES-11879) – LibCrypt Crack
- PGA European Tour Golf (SLES-02396) – LibCrypt Crack
- Radikal Bikers (SLES-01943) – LibCrypt Crack
- Super Tokusatsu Taisen 2001 (SLPS-02863) – Crash Fix
- Sydney 2000 (SLES-02861) – LibCrypt Crack
- Um Jammer Lammy (SCES-01753) – Crash Fix
- Um Jammer Lammy (SCPS-18011) – Crash Fix
- Um Jammer Lammy (SCUS-94448) – Crash Fix

### POPStarter Revision 13, Build Date : 2015/06/03, WIP 05 PUBLIC RELEASE
*[From wip05 documentation]*

**461 DISCS** are recognised.

*The WIP 05 documentation lists every recognised disc with its exact fix description. The entries below preserve the per-game fix wording unique to that snapshot — note especially the items not present in later snapshots (e.g. the Metal Gear Solid "Skip Metal Gear Featured Cutscenes" set, the "2nd VMC is disabled" Codename/Lifeforce Tenka entries, the Tomb Raider "VSync Fix" set, Dance Dance Revolution / DonPachi / Tobal 2 0×06 entries, and the various "Crash Fix / Boot And Load Fix" descriptions).*

- 007: Demain Ne Meurt Jamais (SLES-02375) – Crash Fix
- 007: Der Morgen Stirbt Nie (SLES-02376) – Crash Fix
- 007: Tomorrow Never Dies (SLES-01324) – Crash Fix
- 007: Tomorrow Never Dies (SLPS-02604) – Crash Fix
- 007: Tomorrow Never Dies (SLUS-00975) – Crash Fix
- 40 Winks (SLUS-00874) – Compatibility Mode 0×04
- Actua Ice Hockey 2 (SLES-01226) – LibCrypt Crack
- Akumajou Dracula X: Gekka No Yasoukyoku v1.0 (SLPM-86023) – Compatibility Mode 0×01
- Akumajou Dracula X: Gekka No Yasoukyoku v1.1 (SLPM-86023) – Compatibility Mode 0×01
- Akumajou Dracula X: Gekka No Yasoukyoku v1.2 (SLPM-86023) – Compatibility Mode 0×01
- Akumajou Dracula X: Gekka No Yasoukyoku v1.2 (SLPM-86023, En by Gemini+Throughhim413 v1.0) – Compatibility Mode 0×01
- Anstoss: Premier Manager (SLES-02563) – LibCrypt Crack
- Ape Escape (SCES-01564) – LibCrypt Crack
- Ape Escape (SCES-02028) – LibCrypt Crack
- Ape Escape (SCES-02029) – LibCrypt Crack
- Ape Escape (SCES-02030) – LibCrypt Crack
- Ape Escape (SCES-02031) – LibCrypt Crack
- Apocalypse (SLES-00460) – Compatibility Mode 0×01
- Apocalypse (SLES-00834) – Compatibility Mode 0×01
- Apocalypse (SLES-00835, Megera) – Compatibility Mode 0×01
- Apocalypse (SLES-01463) – Compatibility Mode 0×01
- Apocalypse (SLUS-00373) – Compatibility Mode 0×01
- ASCII Entertainment Demo CD (SLUS-90010) – Compatibility Mode 0×04
- Asterix Mega Madness (SLES-03324) – LibCrypt Crack
- Barbie: Race & Ride (SCES-02365) – LibCrypt Crack
- Barbie: Race & Ride (SCES-02366) – LibCrypt Crack
- Barbie: Race & Ride (SCES-02367) – LibCrypt Crack
- Barbie: Race & Ride (SCES-02369) – LibCrypt Crack
- Barbie: Sports Extreme (SCES-02488) – LibCrypt Crack
- Barbie: Super Sport (SCES-02489) – LibCrypt Crack
- Barbie: Super Sports (SCES-02491) – LibCrypt Crack
- BDFL Manager 2001 (SLES-02977) – LibCrypt Crack – Compatibility Mode 0×04
- BDFL Manager 2002 (SLES-03605) – LibCrypt Crack – Compatibility Mode 0×04
- Beat Mania 6th Mix + Core Remix (SLPM-87012) – Compatibility Mode 0×01
- Beat Mania 6th Mix + Core Remix (SLPM-87012, R18) – Compatibility Mode 0×01
- Bio Hazard v1.1 (SLPS-00222) – Compatibility Mode 0×05
- Bio Hazard: Director's Cut (SLPS-00998) – Compatibility Mode 0×05
- Bio Hazard: Director's Cut: Dual Shock Ver. (SLPS-01512) – Compatibility Mode 0×05
- Bloody Roar II (SCUS-94424) – Compatibility Mode 0×04
- Bust A Groove (SCUS-94263) – Compatibility Mode 0×04
- Bust A Groove 2 (SLUS-01159) – Compatibility Mode 0×04
- Bust A Move 2: Dance Tengoku Mix (SLPM-86219) – Compatibility Mode 0×04
- Bust A Move: Dance & Rhythm Action v1.0 (SLPS-01232) – Compatibility Mode 0×04
- Bust A Move: Dance & Rhythm Action v1.1 (SLPS-01232) – Compatibility Mode 0×04
- Bust-A-Groove (SCES-01313) – Compatibility Mode 0×04
- Canal+ Premier Manager (SLES-02293) – LibCrypt Crack
- Capcom Generation: Dai 5 Shuu Kakutouka Tachi (SLPS-01725) – Compatibility Mode 0×01
- Captain Tsubasa J: Get In The Tomorrow (SLPS-00310) – Compatibility Mode 0×04
- Castlevania: Symphony Of The Night (SLES-00524) – Compatibility Mode 0×01
- Castlevania: Symphony Of The Night (SLUS-00067) – Compatibility Mode 0×01
- Chessmaster II (SLES-02117) – Compatibility Mode 0×04
- Chrono Cross (Disc 1) (SLUS-01041) – Compatibility Mode 0×04
- Chrono Cross (Disc 2) (SLUS-01080) – Compatibility Mode 0×04
- Circuit Breakers (SLUS-00697) – Compatibility Mode 0×04
- Clock Tower (SLES-00870) – Compatibility Mode 0×04
- Clock Tower (SLES-00871) – Compatibility Mode 0×04
- Clock Tower (SLUS-00539) – Compatibility Mode 0×04
- Clock Tower 2 (SLPS-00657) – Compatibility Mode 0×04
- Clock Tower 2 (Taikenban) (SLPM-80063) – Compatibility Mode 0×04
- Clock Tower II: The Struggle Within (SLUS-00695) – Compatibility Mode 0×04
- Clock Tower II: The Struggle Within (SLUS-00695, RGR) – Compatibility Mode 0×04
- Clock Tower: Ghost Head (SLPS-01290) – Compatibility Mode 0×04
- Codename: Tenka (SCUS-94409, Kudos) – 2nd VMC is disabled
- Codename: Tenka v1.0 (SCUS-94409) – 2nd VMC is disabled
- Colony Wars (Disc 1) (SLES-00860) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Colony Wars (Disc 1) (SLES-00861) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Colony Wars (Disc 1) (SLUS-00543) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Colony Wars (Disc 2) (SLES-10860) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Colony Wars (Disc 2) (SLES-10861) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Colony Wars (Disc 2) (SLUS-00554) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Colony Wars (SLED-00091) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Colony Wars: Red Sun (SCES-01924) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Colony Wars: Red Sun (SCES-02621) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Colony Wars: Red Sun (SCES-02623) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Colony Wars: Red Sun (SLUS-00866) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Colony Wars: Vengeance (SLES-01392) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Colony Wars: Vengeance (SLES-01405) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Colony Wars: Vengeance (SLUS-00722) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Cool Boarders (SCES-00568) – Compatibility Mode 0×03
- Cool Boarders (SCUS-94356) – Compatibility Mode 0×03
- Cool Boarders 2 (SCES-00992) – Compatibility Mode 0×03
- Cool Boarders 2 (SCUS-94358) – Compatibility Mode 0×03
- Cool Boarders 2: Killing Session (SLPS-00967) – Compatibility Mode 0×03
- Crash Bandicoot Racing (SCPS-10118) – Boot Fix – Load Fix
- Crash Bash (SCES-02834) – LibCrypt Crack
- Crash Team Racing (SCUS-94426) – Boot And Load Fix
- Critical Blow (SLPS-01044) – Compatibility Mode 0×04
- CTR: Crash Team Racing (SCES-02105) – LibCrypt Crack – Boot And Load Fix
- Dance Dance Revolution: Disney's Rave (SLPM-86667) – Compatibility Mode 0×06
- Dance Dance Revolution: Disney's Rave (SLPM-86667, R18) – Compatibility Mode 0×06
- Dead Or Alive (SCES-01259) – Compatibility Mode 0×04
- Dead Or Alive (SLPS-01289) – Compatibility Mode 0×04 – Compatibility Mode 0×06
- Dead Or Alive (SLUS-00606) – Compatibility Mode 0×04
- Destruction Derby 2 (SCUS-94350) – Crash Fix
- Destruction Derby 2 (SIPS-60012) – Crash Fix
- Destruction Derby 2 (SLES-00299) – Crash Fix
- Die Hard Trilogy (SLES-00445) – Compatibility Mode 0×03
- Die Hard Trilogy v1.0 (SLUS-00119) – Compatibility Mode 0×03
- Die Hard Trilogy v1.1 (SLUS-00119) – Compatibility Mode 0×03
- Dino Crisis (SLES-02207) – LibCrypt Crack
- Dino Crisis (SLES-02208) – LibCrypt Crack
- Dino Crisis (SLES-02209) – LibCrypt Crack
- Dino Crisis (SLES-02210) – LibCrypt Crack
- Dino Crisis (SLES-02211) – LibCrypt Crack
- Disney Fais Ton Histoire!: Mulan (SCES-02004) – LibCrypt Crack – Compatibility Mode 0×01
- Disney Libro Animato Creativo: Mulan (SCES-02006) – LibCrypt Crack – Compatibility Mode 0×01
- Disney Tarzan (SCES-01516) – LibCrypt Crack
- Disney Tarzan (SCES-01519) – LibCrypt Crack
- Disney's 102 Dalmatians: Puppies To The Rescue (SLES-03191) – LibCrypt Crack
- Disney's Aventura Interactiva: Mulan (SCES-02007) – LibCrypt Crack – Compatibility Mode 0×01
- Disney's Story Studio: Mulan (SCES-01695) – LibCrypt Crack – Compatibility Mode 0×01
- Disneys Interaktive Abenteuer: Mulan (SCES-02005) – LibCrypt Crack – Compatibility Mode 0×01
- Disneys Tarzan (SCES-01518) – LibCrypt Crack
- DonPachi (SLPS-00548) – Compatibility Mode 0×06
- Double Dragon (SLPS-00191) – Compatibility Mode 0×03
- Dragon Valor (Disc 1) (SCES-01705) – Compatibility Mode 0×04
- Dragon Valor (Disc 1) (SCES-02565) – Compatibility Mode 0×04
- Dragon Valor (Disc 1) (SCES-02566) – Compatibility Mode 0×04
- Dragon Valor (Disc 1) (SCES-02567) – Compatibility Mode 0×04
- Dragon Valor (Disc 1) (SCES-02568) – Compatibility Mode 0×04
- Dragon Valor (Disc 1) (SLPS-02190) – Compatibility Mode 0×04
- Dragon Valor (Disc 1) (SLUS-01092) – Compatibility Mode 0×04
- Dragon Valor (Disc 2) (SCES-11705) – Compatibility Mode 0×04
- Dragon Valor (Disc 2) (SCES-12565) – Compatibility Mode 0×04
- Dragon Valor (Disc 2) (SCES-12566) – Compatibility Mode 0×04
- Dragon Valor (Disc 2) (SCES-12567) – Compatibility Mode 0×04
- Dragon Valor (Disc 2) (SCES-12568) – Compatibility Mode 0×04
- Dragon Valor (Disc 2) (SLPS-02191) – Compatibility Mode 0×04
- Dragon Valor (Disc 2) (SLUS-01164) – Compatibility Mode 0×04
- EA Sports Superbike 2000 (SLES-02538) – LibCrypt Crack
- Eagle One: Harrier Attack (SLES-01715) – LibCrypt Crack
- Enigma (Disc 1) (SLPS-01351) – Compatibility Mode 0×04
- Enigma (Disc 2) (SLPS-01352) – Compatibility Mode 0×04
- Esto Es Futbol (SCES-01704) – LibCrypt Crack
- F1 2000 (SLES-02722) – LibCrypt Crack
- F1 2000 (SLES-02724) – LibCrypt Crack
- Final Fantasy IX (Disc 1) (SLES-02965) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 1) (SLES-02966) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 1) (SLES-02967) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 1) (SLES-02968) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 1) (SLES-02969) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 1) (SLPS-02000) – Compatibility Mode 0×04
- Final Fantasy IX (Disc 1) (SLUS-01251) – Compatibility Mode 0×04
- Final Fantasy IX (Disc 2) (SLES-12965) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 2) (SLES-12966) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 2) (SLES-12967) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 2) (SLES-12968) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 2) (SLES-12969) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 2) (SLPS-02001) – Compatibility Mode 0×04
- Final Fantasy IX (Disc 2) (SLUS-01295) – Compatibility Mode 0×04
- Final Fantasy IX (Disc 3) (SLES-22965) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 3) (SLES-22966) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 3) (SLES-22967) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 3) (SLES-22968) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 3) (SLES-22969) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 3) (SLPS-02002) – Compatibility Mode 0×04
- Final Fantasy IX (Disc 3) (SLUS-01296) – Compatibility Mode 0×04
- Final Fantasy IX (Disc 4) (SLES-32965) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 4) (SLES-32966) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 4) (SLES-32967) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 4) (SLES-32968) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 4) (SLES-32969) – LibCrypt Crack – Compatibility Mode 0×04
- Final Fantasy IX (Disc 4) (SLPS-02003) – Compatibility Mode 0×04
- Final Fantasy IX (Disc 4) (SLUS-01297) – Compatibility Mode 0×04
- Final Fantasy VIII (Disc 1) (SLES-02080) – LibCrypt Crack
- Final Fantasy VIII (Disc 1) (SLES-02081) – LibCrypt Crack
- Final Fantasy VIII (Disc 1) (SLES-02082) – LibCrypt Crack
- Final Fantasy VIII (Disc 1) (SLES-02083) – LibCrypt Crack
- Final Fantasy VIII (Disc 1) (SLES-02084) – LibCrypt Crack
- Final Fantasy VIII (Disc 2) (SLES-12080) – LibCrypt Crack
- Final Fantasy VIII (Disc 2) (SLES-12081) – LibCrypt Crack
- Final Fantasy VIII (Disc 2) (SLES-12082) – LibCrypt Crack
- Final Fantasy VIII (Disc 2) (SLES-12083) – LibCrypt Crack
- Final Fantasy VIII (Disc 2) (SLES-12084) – LibCrypt Crack
- Final Fantasy VIII (Disc 3) (SLES-22080) – LibCrypt Crack
- Final Fantasy VIII (Disc 3) (SLES-22081) – LibCrypt Crack
- Final Fantasy VIII (Disc 3) (SLES-22082) – LibCrypt Crack
- Final Fantasy VIII (Disc 3) (SLES-22083) – LibCrypt Crack
- Final Fantasy VIII (Disc 3) (SLES-22084) – LibCrypt Crack
- Final Fantasy VIII (Disc 4) (SLES-32080) – LibCrypt Crack
- Final Fantasy VIII (Disc 4) (SLES-32081) – LibCrypt Crack
- Final Fantasy VIII (Disc 4) (SLES-32082) – LibCrypt Crack
- Final Fantasy VIII (Disc 4) (SLES-32083) – LibCrypt Crack
- Final Fantasy VIII (Disc 4) (SLES-32084) – LibCrypt Crack
- Formula One 99 (SCES-01979) – LibCrypt Crack
- Frogger (SLES-00704) – Compatibility Mode 0×04
- Frogger (SLUS-00506) – Compatibility Mode 0×04
- Frontschweine (SLES-02767) – LibCrypt Crack
- Fussball Live (SCES-01702) – LibCrypt Crack
- Future Racer (SLES-03508) – Crash Fix – Compatibility Mode 0×04
- Galerians (Disc 1) (SLES-02328) – LibCrypt Crack
- Galerians (Disc 1) (SLES-02329) – LibCrypt Crack
- Galerians (Disc 1) (SLES-02330) – LibCrypt Crack
- Galerians (Disc 2) (SLES-12328) – LibCrypt Crack
- Galerians (Disc 2) (SLES-12329) – LibCrypt Crack
- Galerians (Disc 2) (SLES-12330) – LibCrypt Crack
- Galerians (Disc 3) (SLES-22328) – LibCrypt Crack
- Galerians (Disc 3) (SLES-22329) – LibCrypt Crack
- Galerians (Disc 3) (SLES-22330) – LibCrypt Crack
- Gekido: Urban Fighters (SLES-01241) – LibCrypt Crack
- Gex 3D: Enter The Gecko (SLES-00596) – Compatibility Mode 0×04
- Gran Turismo (PAPX-90026) – Compatibility Mode 0×04
- Gran Turismo (SCES-00984) – Compatibility Mode 0×04
- Gran Turismo (SCPS-10045) – Compatibility Mode 0×04
- Gran Turismo 2 (Arcade Mode) v1.0 (SCUS-94455) – Compatibility Mode 0×01 – Compatibility Mode 0×04
- Gran Turismo 2 (Arcade Mode) v1.1 (SCUS-94455) – Compatibility Mode 0×01 – Compatibility Mode 0×04
- Gran Turismo 2 (Disc 1) (Arcade Mode) (SCES-02380) – Compatibility Mode 0×01 – Compatibility Mode 0×04
- Gran Turismo 2 (Disc 1) (Arcade) (SCPS-10116) – Compatibility Mode 0×01 – Compatibility Mode 0×04
- Gran Turismo 2 (Disc 2) (Gran Turismo) v1.0 (SCPS-10117) – Compatibility Mode 0×01 – Compatibility Mode 0×04
- Gran Turismo 2 (Disc 2) (Gran Turismo) v1.1 (SCPS-10117) – Compatibility Mode 0×01 – Compatibility Mode 0×04
- Gran Turismo 2 (Disc 2) (GT Mode) (SCES-12380) – Compatibility Mode 0×01 – Compatibility Mode 0×04
- Gran Turismo 2 (Simulation Mode) v1.0 (SCUS-94488) – Compatibility Mode 0×01 – Compatibility Mode 0×04
- Gran Turismo 2 (Simulation Mode) v1.1 (SCUS-94488) – Compatibility Mode 0×01 – Compatibility Mode 0×04
- Gran Turismo 2 (Simulation Mode) v1.2 (SCUS-94488) – Compatibility Mode 0×01 – Compatibility Mode 0×04
- Gran Turismo v1.0 (SCUS-94194) – Compatibility Mode 0×04
- Gran Turismo v1.1 (SCUS-94194) – Compatibility Mode 0×04
- Grandia (Disc 1) (SCUS-94457) – Compatibility Mode 0×04
- Grandia (Disc 1) (SLES-02397) – Compatibility Mode 0×04
- Grandia (Disc 1) (SLES-02398) – Compatibility Mode 0×04
- Grandia (Disc 1) (SLES-02399) – Compatibility Mode 0×04
- Grandia (Disc 1) (SLPS-02124) – Compatibility Mode 0×04
- Grandia (Disc 2) (SCUS-94465) – Compatibility Mode 0×04
- Grandia (Disc 2) (SLES-12397) – Compatibility Mode 0×04
- Grandia (Disc 2) (SLES-12398) – Compatibility Mode 0×04
- Grandia (Disc 2) (SLES-12399) – Compatibility Mode 0×04
- Grandia (Disc 2) (SLPS-02125) – Compatibility Mode 0×04
- Grandia: Prologue (Taikenban) (SLPM-80297) – Compatibility Mode 0×04
- Harry Potter And The Chamber Of Secrets (SLES-03972) – Crash Fix
- Harry Potter And The Chamber Of Secrets (SLES-03973) – Crash Fix
- Harry Potter And The Chamber Of Secrets (SLES-03974) – Crash Fix
- Harry Potter And The Chamber Of Secrets (SLUS-01503) – Crash Fix
- Harry Potter And The Philosopher's Stone (SLES-03662) – Crash Fix
- Harry Potter And The Philosopher's Stone (SLES-03663) – Crash Fix
- Harry Potter And The Philosopher's Stone (SLES-03664) – Crash Fix
- Harry Potter And The Philosopher's Stone (SLES-03665) – Crash Fix
- Harry Potter And The Sorcerer's Stone (SLUS-01415) – Crash Fix
- Harry Potter To Kenja No Ishi (SLPS-03355) – Crash Fix
- Hogs Of War (SLES-01041) – LibCrypt Crack
- Hogs Of War (SLES-02769) – LibCrypt Crack
- Jumping Flash! (SCUS-94103) – Compatibility Mode 0×01 – Compatibility Mode 0×04
- Jumping Flash! 2 (SCUS-94108) – Compatibility Mode 0×04
- Le Mans 24 Hours (SLES-01362) – LibCrypt Crack
- Le Monde Des Bleus (SCES-01701) – LibCrypt Crack
- Legacy Of Kain: Soul Reaver (SLES-01301) – LibCrypt Crack
- Legacy Of Kain: Soul Reaver (SLES-02024) – LibCrypt Crack
- Legacy Of Kain: Soul Reaver (SLES-02025) – LibCrypt Crack
- Legacy Of Kain: Soul Reaver (SLES-02026) – LibCrypt Crack
- Legacy Of Kain: Soul Reaver (SLES-02027) – LibCrypt Crack
- Legaia Densetsu (SCPS-10059) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Legend Of Legaia (SCES-01752) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Legend Of Legaia (SCES-01944) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Legend Of Legaia (SCES-01945) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Legend Of Legaia (SCES-01946) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Legend Of Legaia (SCES-01947) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Legend Of Legaia (SCUS-94254) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Legend Of Legaia (SCUS-94366) – Compatibility Mode 0×02 – Compatibility Mode 0×04
- Les Cochons De Guerre (SLES-02766) – LibCrypt Crack
- Lifeforce: Tenka (SLES-00614) – 2nd VMC is disabled
- Lifeforce: Tenka (SLES-00615) – 2nd VMC is disabled
- LMA Manager 2001 (SLES-02975) – LibCrypt Crack – Compatibility Mode 0×04
- LMA Manager 2002 (SLES-03603) – LibCrypt Crack – Compatibility Mode 0×04
- Lucky Luke: Western Fever (SLES-03530) – Title Specific LibCrypt Crack
- Mánager De Liga 2001 (SLES-02979) – LibCrypt Crack – Compatibility Mode 0×04
- Mánager De Liga 2002 (SLES-03607) – LibCrypt Crack – Compatibility Mode 0×04
- Marranos En Guerra (SLES-02768) – LibCrypt Crack
- Marvel Super Heroes Vs. Street Fighter (SLES-01792) – Compatibility Mode 0×01
- Marvel Super Heroes Vs. Street Fighter (SLUS-00793) – Compatibility Mode 0×01
- Marvel Super Heroes Vs. Street Fighter: EX Edition (SLPS-01915) – Compatibility Mode 0×01
- Marvel Super Heroes Vs. Street Fighter: EX Edition (Taikenban) (SLPM-80376) – Compatibility Mode 0×01
- Marvel Vs. Capcom: Clash Of Super Heroes (SLES-02305) – Compatibility Mode 0×01
- Marvel Vs. Capcom: Clash Of Super Heroes (SLUS-01059) – Compatibility Mode 0×01
- Marvel Vs. Capcom: Clash Of Super Heroes: EX Edition (SLPS-02368) – Compatibility Mode 0×01
- MediEvil (SCES-01492) – LibCrypt Crack – Compatibility Mode 0×01
- MediEvil (SCES-01494) – LibCrypt Crack – Compatibility Mode 0×01
- MediEvil (SCES-01495) – LibCrypt Crack – Compatibility Mode 0×01
- MediEvil (SCUS-94227) – Compatibility Mode 0×01
- MediEvil 2 (SCES-02544) – LibCrypt Crack
- MediEvil 2 (SCES-02545) – LibCrypt Crack
- MediEvil 2 (SCES-02546) – LibCrypt Crack
- MediEvil v1.1 (SCES-00311) – LibCrypt Crack – Compatibility Mode 0×01
- Men In Black: The Series: Crashdown (SLES-03519) – LibCrypt Crack
- Men In Black: The Series: Crashdown (SLES-03522) – LibCrypt Crack
- Metal Gear Solid (Disc 1) (SLES-01370) – Skip Metal Gear Featured Cutscenes
- Metal Gear Solid (Disc 1) (SLES-01506) – Skip Metal Gear Featured Cutscenes
- Metal Gear Solid (Disc 1) (SLES-01507) – Skip Metal Gear Featured Cutscenes
- Metal Gear Solid (Disc 1) (SLES-01508) – Skip Metal Gear Featured Cutscenes
- Metal Gear Solid (Disc 1) (SLES-01734) – Skip Metal Gear Featured Cutscenes
- Metal Gear Solid (Disc 1) (SLPM-86111) – Skip Metal Gear Featured Cutscenes
- Metal Gear Solid v1.0 (Disc 1) (SLUS-00594) – Skip Metal Gear Featured Cutscenes
- Metal Gear Solid v1.1 (Disc 1) (SLUS-00594) – Skip Metal Gear Featured Cutscenes
- Michelin Rally Masters: Race Of Champions (SLES-01545) – LibCrypt Crack
- Michelin Rally Masters: Race Of Champions (SLES-02395) – LibCrypt Crack
- Mike Tyson Boxing (SLES-02839) – LibCrypt Crack
- Mission: Impossible (SLES-01906) – LibCrypt Crack
- Mizzurna Falls (SLPS-01783) – Compatibility Mode 0×04
- Mobil 1 Rally Championship (SLES-02574) – Compatibility Mode 0×04
- Mobil 1 Rally Championship (SLUS-01103) – Compatibility Mode 0×04
- MoHo (SLES-02830) – LibCrypt Crack
- Muppet RaceMania (SLUS-01237) – Compatibility Mode 0×04
- Myst (SCUS-94602) – Compatibility Mode 0×04
- Myst (SLES-00218) – Compatibility Mode 0×04
- Myst v1.0 (SLPS-00024) – Compatibility Mode 0×04
- Myst v1.1 (SLPS-91023) – Compatibility Mode 0×04
- Need For Speed: Porsche 2000 (SLES-02689) – LibCrypt Crack
- Need For Speed: Porsche 2000 (SLES-02700) – LibCrypt Crack
- N-Gen Racing (SLES-02086) – LibCrypt Crack – Compatibility Mode 0×04
- N-Gen Racing (SLUS-01155) – Compatibility Mode 0×04
- Nightmare Creatures II (SLES-02751) – Compatibility Mode 0×04
- Nightmare Creatures II (SLUS-01112) – Compatibility Mode 0×04
- Pac-Man World (SLUS-00439) – Compatibility Mode 0×04
- PaRappa The Rapper (SCES-00743) – Compatibility Mode 0×04
- PaRappa The Rapper (SCUS-94183) – Compatibility Mode 0×04
- Parasite Eve II (Disc 1) (SLES-02558) – LibCrypt Crack
- Parasite Eve II (Disc 1) (SLES-02559) – LibCrypt Crack
- Parasite Eve II (Disc 1) (SLES-02560) – LibCrypt Crack
- Parasite Eve II (Disc 1) (SLES-02561) – LibCrypt Crack
- Parasite Eve II (Disc 1) (SLES-02562) – LibCrypt Crack
- Parasite Eve II (Disc 2) (SLES-12558) – LibCrypt Crack
- Parasite Eve II (Disc 2) (SLES-12559) – LibCrypt Crack
- Parasite Eve II (Disc 2) (SLES-12560) – LibCrypt Crack
- Parasite Eve II (Disc 2) (SLES-12561) – LibCrypt Crack
- Parasite Eve II (Disc 2) (SLES-12562) – LibCrypt Crack
- PGA European Tour Golf (SLES-02061) – LibCrypt Crack
- Pop'n Music (SLPM-87089) – Compatibility Mode 0×01
- Porsche Challenge (SCES-00409) – Compatibility Mode 0×02
- Porsche Challenge (SCUS-94187) – Compatibility Mode 0×02
- Porsche Challenge (SIPS-60016) – Compatibility Mode 0×02
- Premier Manager 2000 (SLES-02292) – LibCrypt Crack
- Prince Naseem Boxing (SLES-00017) – LibCrypt Crack
- Rapid Racer (SCES-00394) – Compatibility Mode 0×04
- Ray Crisis (SLES-02882) – Compatibility Mode 0×04
- Raycrisis (SLPM-86450) – Compatibility Mode 0×04
- Raycrisis: Series Termination (SLUS-01217) – Compatibility Mode 0×04
- RC Revenge (SLES-02824) – LibCrypt Crack
- Resident Evil (SLUS-00170) – Compatibility Mode 0×05
- Resident Evil 3: Nemesis (SLES-02529) – LibCrypt Crack
- Resident Evil 3: Nemesis (SLES-02530) – LibCrypt Crack
- Resident Evil 3: Nemesis (SLES-02531) – LibCrypt Crack
- Resident Evil 3: Nemesis (SLES-02532) – LibCrypt Crack
- Resident Evil 3: Nemesis (SLES-02533) – LibCrypt Crack
- Resident Evil: Director's Cut (SLES-00969) – Compatibility Mode 0×05
- Resident Evil: Director's Cut (SLES-00970) – Compatibility Mode 0×05
- Resident Evil: Director's Cut (SLUS-00551) – Compatibility Mode 0×05
- Resident Evil: Director's Cut: Dual Shock Ver. (SLUS-00747) – Compatibility Mode 0×05
- Roadsters (SLES-02326) – Crash Fix
- Roadsters (SLUS-01024) – Crash Fix
- Ronaldo V-Football (SLES-00995) – LibCrypt Crack
- Ronaldo V-Football (SLES-02681) – LibCrypt Crack
- SaGa Frontier 2 (SLES-02112) – LibCrypt Crack
- SaGa Frontier 2 (SLES-02113) – LibCrypt Crack
- SaGa Frontier 2 (SLES-02118) – LibCrypt Crack
- Silent Hill (SLED-01735) – Compatibility Mode 0×04
- Silent Hill (SLES-01514) – Compatibility Mode 0×04
- Silent Hill (SLUS-00707) – Compatibility Mode 0×04
- Silent Hill v1.0 (SLPM-86192) – Compatibility Mode 0×04
- Silent Hill v1.1 (SLPM-86192) – Compatibility Mode 0×04
- Sled Storm (SLES-02194) – Compatibility Mode 0×04
- Sno-Cross Championship Racing (SLES-02763) – LibCrypt Crack
- Space Debris (SCES-02290) – LibCrypt Crack
- Space Debris (SCES-02430) – LibCrypt Crack
- Space Debris (SCES-02432) – LibCrypt Crack
- Speed Freaks (SCES-01763) – LibCrypt Crack
- Spyro 2: Gateway To Glimmer (SCES-02104) – LibCrypt Crack
- Spyro: Year Of The Dragon v1.0 (SCES-02835) – LibCrypt Crack
- Spyro: Year Of The Dragon v1.0 (SCUS-94467) – Compatibility Mode 0×01
- Spyro: Year Of The Dragon v1.1 (SCES-02835) – LibCrypt Crack
- Spyro: Year Of The Dragon v1.1 (SCUS-94467) – Compatibility Mode 0×01
- Star Gladiator: Episode 1: Final Crusade (SLES-00495) – Compatibility Mode 0×04
- Star Gladiator: Episode 1: Final Crusade (SLPS-00539) – Compatibility Mode 0×04
- Star Gladiator: Episode 1: Final Crusade (SLUS-00372) – Compatibility Mode 0×04
- Street Fighter Collection 2 (SLES-01721) – Compatibility Mode 0×01
- Street Fighter Collection 2 (SLUS-00746) – Compatibility Mode 0×01
- Street Fighter EX Plus Alpha (SLES-00939) – Compatibility Mode 0×04
- Street Fighter EX Plus Alpha (SLPM-86041) – Compatibility Mode 0×04
- Street Fighter EX Plus Alpha (SLUS-00548) – Compatibility Mode 0×04
- Strikers 1945 (SLPS-00407) – Compatibility Mode 0×04
- Super Puzzle Fighter II Turbo (SLES-00605) – Compatibility Mode 0×01
- Super Puzzle Fighter II Turbo (SLUS-00418) – Compatibility Mode 0×01
- Sydney 2000 (SLES-02857) – LibCrypt Crack
- Sydney 2000 (SLES-02860) – LibCrypt Crack
- Syphon Filter (SCES-01910) – Compatibility Mode 0×04
- Syphon Filter (SCES-01911) – Compatibility Mode 0×04
- Syphon Filter (SCES-01913) – Compatibility Mode 0×04
- Syphon Filter (SCES-01914) – Compatibility Mode 0×04
- Syphon Filter (SLPS-02216) – Compatibility Mode 0×04
- Syphon Filter v1.0 (SCUS-94240) – Compatibility Mode 0×04
- Syphon Filter v1.1 (SCUS-94240) – Compatibility Mode 0×04
- TechnoMage: El Retorno De La Eternidad (SLES-03244) – LibCrypt Crack
- TechnoMage: En Quete de L'Eternite (SLES-03242) – LibCrypt Crack
- TechnoMage: Return Of Eternity (SLES-03241) – LibCrypt Crack
- TechnoMage: Ritorno All'Eternita (SLES-03243) – LibCrypt Crack
- Tekken 3 (SCES-01237) – Compatibility Mode 0×01
- Tekken 3 (SLUS-00402) – Compatibility Mode 0×01
- Tekken 3 v1.0 (SLPS-01300 / SLPS-91202) – Compatibility Mode 0×01 – Compatibility Mode 0×06
- Test Drive 4 (SLES-00948) – Compatibility Mode 0×04
- Test Drive 4 (SLUS-00487) – Compatibility Mode 0×04
- Test Drive 4×4 (SLES-01179) – Compatibility Mode 0×04
- The F.A Premier League Manager 2001 (SLES-03061) – LibCrypt Crack
- The Italian Job (SLES-03489) – LibCrypt Crack
- The Italian Job (SLES-03626) – LibCrypt Crack
- Theme Park World (SLES-02688) – LibCrypt Crack
- This Is Football (SCES-01700) – LibCrypt Crack
- This Is Football (SCES-01703) – LibCrypt Crack
- Tobal 2 v1.1 (SLPM-86033) – Compatibility Mode 0×06
- Tobal No.1 (SCUS-94208) – Compatibility Mode 0×04
- Tobal No.1 (SLPM-87405 / SLPS-00400) – Compatibility Mode 0×04 – Compatibility Mode 0×06
- TOCA World Touring Cars (SLES-02572) – LibCrypt Crack
- TOCA World Touring Cars (SLES-02573) – LibCrypt Crack
- Tomb Raider (SLES-00024) – VSync Fix
- Tomb Raider (SLES-00485) – VSync Fix
- Tomb Raider (SLES-00486) – VSync Fix
- Tomb Raider 2 (SLPS-01200) – VSync Fix
- Tomb Raider II: Starring Lara Croft (Beta 1997-09-30) – VSync Fix
- Tomb Raider II: Starring Lara Croft (SLES-00107) – VSync Fix
- Tomb Raider II: Starring Lara Croft (SLES-00718) – VSync Fix
- Tomb Raider II: Starring Lara Croft (SLES-00719) – VSync Fix
- Tomb Raider II: Starring Lara Croft (SLES-00720) – VSync Fix
- Tomb Raider II: Starring Lara Croft v1.0 (SLUS-00437) – VSync Fix
- Tomb Raider II: Starring Lara Croft v1.1 (SLUS-00437) – VSync Fix
- Tomb Raider II: Starring Lara Croft v1.2 (SLUS-00437) – VSync Fix
- Tomb Raider II: Starring Lara Croft v1.3 (SLUS-00437) – VSync Fix
- Tomb Raider v1.0 (SLUS-00152) – VSync Fix
- Tomb Raider v1.1 (SLUS-00152) – VSync Fix
- Tomb Raider v1.2 (SLUS-00152) – VSync Fix
- Tomb Raider v1.3 (SLUS-00152) – VSync Fix
- Tomb Raider v1.4 (SLUS-00152) – VSync Fix
- Tomb Raider v1.5 (SLUS-00152) – VSync Fix
- Tomb Raider v1.6 (SLUS-00152) – VSync Fix
- Tomb Raiders (SLPS-00617) – VSync Fix
- Turbo Prop Racing (SCUS-94229) – Compatibility Mode 0×04
- UEFA Euro 2000 (SLES-02704) – LibCrypt Crack
- UEFA Euro 2000 (SLES-02706) – LibCrypt Crack
- UEFA Euro 2000 (SLES-02707) – LibCrypt Crack
- UEFA Striker (SLES-01733) – LibCrypt Crack
- Urban Chaos (SLES-02071) – LibCrypt Crack
- Urban Chaos (SLES-02354) – LibCrypt Crack
- Vagrant Story (SLES-02754) – LibCrypt Crack
- Vagrant Story (SLES-02755) – LibCrypt Crack
- Vagrant Story (SLES-02756) – LibCrypt Crack
- Vigilante 8: 2nd Battle (SLPS-02615) – Compatibility Mode 0×04
- Vigilante 8: 2nd Offense (SLES-02162) – Compatibility Mode 0×04
- Vigilante 8: 2nd Offense (SLUS-00868) – Compatibility Mode 0×04
- V-Rally: Championship Edition 2 (SLES-01907) – LibCrypt Crack
- Walt Disney World Quest: Magical Racing Tour (SLES-02733) – LibCrypt Crack
- Wild 9 (SLES-01333) – Compatibility Mode 0×04
- Wild 9 (SLUS-00425) – Compatibility Mode 0×04
- Wildroid 9 (SCPS-10080) – Compatibility Mode 0×04
- Wip3out (SCES-01909) – Compatibility Mode 0×04
- WipEout (SCUS-94301) – Crash Fix
- WipEout (SIPS-60003) – Crash Fix
- WipEout 2097 (SLES-00327) – Compatibility Mode 0×04
- WipEout 3 (SCPS-10098) – Compatibility Mode 0×04
- WipEout 3 (SLUS-00865) – Compatibility Mode 0×04
- WipEout 3: Special Edition (SCES-02845) – Compatibility Mode 0×04
- WipEout v1.0 (SCES-00010) – Crash Fix
- WipEout v1.1 (SCES-00010) – Crash Fix
- Wipeout XL (SCUS-94351) – Compatibility Mode 0×04
- Wipeout XL (SIPS-60010) – Compatibility Mode 0×04
- WWF SmackDown! 2: Know Your Role (SLUS-01234) – Compatibility Mode 0×04
- X-Men: Children Of The Atom (SLES-00198) – Compatibility Mode 0×04
- X-Men: Children Of The Atom (SLUS-00044) – Compatibility Mode 0×04

______________________________________________________________________________________________________________

### [**Index**](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/index)
