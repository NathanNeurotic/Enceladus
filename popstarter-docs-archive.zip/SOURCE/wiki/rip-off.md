<!-- source: https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/rip-off -->
<!-- primary snapshot: 20240910181435  |  6 captures, 1 distinct content version(s) -->
# rip-off

# **Rip-offs – warning**

______________________________________________________________________________________________________________

You may find online some POPS-00001 and POPStarter bundles distributed by a guy named *psalmsamuel*. This guy is famous for distributing hexediting homebrews (FMCB [here](http://psx-scene.com/forums/f153/their-scammer-fmcb-115279/) or [here](https://assemblergames.com/threads/ps2-pops-stuff-popstarter.45347/page-18#post-686693) and [Open PS2 Loader](https://assemblergames.com/threads/ps2-pops-stuff-popstarter.45347/page-15#post-685142)  for example…), removing splash screens/logos/credits, replacing texts by its own, spreading lies… He uses various nicknames : psalmsamuel, Yeshuachrist, The_Pot_Of_Greed…

You are strongly adviced to **NOT** use his stuff, as it was proved that is was nothing but [sabotage](https://assemblergames.com/threads/ps2-pops-stuff-popstarter.45347/page-14#post-684424) – which could ruin your PS2 stuff.

**POPS-00001 / POPStarter known bundles distributed by psalmsamuel/yeshuachrist :**

```
"POPS-00001 Emulator Working.rar" - MD5 : 7a3d61bfd48c6cf2db6f38b2f48b53eb - distributed as psalmsamuel ;
"POPS-00001 Working.rar"          - MD5 : 191faf0722f78730c7cf09bdf8071f13 - distributed on a google drive account as psalmsamuel ;
"POPS-00001 Tool Kit.rar"         - MD5 : 6c97a51f87fa7005c731b16b76e2a07f - distributed as yeshuachrist ;
"PS2_Tools_Fixed_Updated.rar"     - MD5 : 469b8877d1a4c4a0aae0457332873903 - distributed as yeshuachrist  ;
"POPSTARTER_Package_11.rar"       - MD5 : cf97c7d103b3689e694467c3e44ebb17 - distributed on a google drive account as psalmsamuel ;
"POPSTARTER_Package_15_7_15.rar"  - MD5 : 4da9d8e27d278ed5b99a99c6f9782fe1 - distributed on a google drive account as yeshuachrist ;
"POPSTARTER_Package_15_7_27.rar"  - MD5 : f4e5e37a9461e6de88885b0fbfbf376f - distributed on a google drive account as yeshuachrist ;
"POPSTARTER_Package__15_6.rar"    - MD5 : 3ed32a3899255953c93a32e478384577 - distributed on a google drive account ;
"POPSTARTER_Package_15_7_22.rar"  - MD5 : 2f55b7a5bcbec074e35e6b6f8e50c854 - distributed on a google drive account ;
```

**Unrelated bundles :**

```
"FMCB_Plus_OPL_Invisible_Icon_and_More.rar"     - MD5 : 9f08e22062b4560ac96633b9d5f311cb ;
"HDD-OSD Plus KERMIT.rar"                       - MD5 : d7338ee6a18267a56dc6c587c36eb5c1 ;
"FMCB_1_8_OPL_0_9_1___8_Invisibility_Icons.rar" - MD5 : 53aace9462391c16c9a05d4a9fe44877 ;
```

______________________________________________________________________________________________________________

### [**Index**](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/index)
