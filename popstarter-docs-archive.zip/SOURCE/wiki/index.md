<!-- source: https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/index -->
<!-- primary snapshot: 20210307092446  |  13 captures, 2 distinct content version(s) -->
<!-- other distinct versions retained in _versions/index/: 20250225124234 -->
# index

# **Wiki – Table of Content**

______________________________________________________________________________________________________________
*[ Original documentation by [krHACKen](https://assemblergames.com/members/khn.105594/) – updated by [shaolinassassin](https://assemblergames.com/members/dasa.76928/) ]*

**Note :** the following documentation is up-to-date with **Rev13 Beta 2019/06/05**.

[**1. POPStarter for Internal HDD**](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/hdd-mode)

- [Requirements](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/hdd-mode)

- [Installation](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/hdd-mode)

- [Example of setup](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/hdd-mode)

- [POPSTARTER.KELF](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/hdd-mode)

- [HDD Launch types](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/hdd-mode)

- [Additional notes](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/hdd-mode)

[**2. POPStarter for USB Device Storage Type**](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/usb-mode)

- [Requirements](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/usb-mode)

- [Installation](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/usb-mode)

- [Example of setup](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/usb-mode)

- [USB Launch type](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/usb-mode)

- [Additional notes](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/usb-mode)

[**3. POPStarter for SMB**](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/smb-mode)

- [Requirements](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/smb-mode)

- [Installation](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/smb-mode)

- [Example of setup](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/smb-mode)

- [SMB Launch type](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/smb-mode)

- [Additional notes](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/smb-mode)

**4. Compatibility**

- [Compatibility lists](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/compatibility)

- [Compatibility modes](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/compatibility)

- [Automated fixes](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/automated)

**5.  Features and Settings**

- [General Note](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/general-note)

- [Virtual Memory Cards](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/vmc)

- [Hotkeys](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/hotkeys)

- [Cheat Engine](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/cheat-engine)

- [Special Cheats](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/special-cheats)

- [In-Game-Reset](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/igr)

- [Swap Disc Feature](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/multi-disc)

- [PS1 CD mode](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/ps1cd-mode)

- [IRX Loader](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/irx-loader)

- [BIOS & OSD Handlers](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/bios-osd-handlers)

- [Debug Mode](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/debug-mode)

- [uLE_kHn](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/uLE_kHn)

- [Advanced Settings](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/configuration-table)

**6. Help**

- [Search in wiki](http://www.google.com/search?q=mysearch%2Bsite%3Ahttps%3A%2F%2Fbitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/)

- [POPStarter Help](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/help)

- [Debug Mode](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/debug-mode)

- [FAQs](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/faqs)

- [Known Bugs](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/known-bugs)

**7. About POPStarter & POPS**

- [Timeline](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/timeline)

- [POPStarter Changelog](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/popstarter-changelog)

- [Toolbox/CUE2POPS Changelog](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/cue2pops-and-toolbox-changelogs)

- [POPS’ History](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/history)

- [Rip-offs – warning](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/rip-off)

[**8. Downloads**](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/downloads)

- [Apps Last Version – Download Links](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/apps-last-version)

**9. Related Stuff…**

- [Softwares](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/related-stuff)

- [Threads – POPStarter around the Web](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/related-stuff)

- Guides/informations :

.......... [HDD] [Transfer VCD files using PFSSHELL 0.2a](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/pfsshell) .
.......... [HDD] [Transfer VCD files over network using RadHostClient](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/radhostclient) .
.......... [HDD] [POPStarter on HDDOSD](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/popstarter-hddosd)
…....... [VMC] [Use your PS1 MC saves with POPStarter](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/pmc-to-vmc)
…....... [VMC] [Use your VMC saves on a PS1 retail console](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/vmc-to-pmc)
…....... [IGR] [Make your own IGR textures](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/igr-textures)
…....... [SPECIAL DEVICE] [Use your [special device] with POPS](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/ps1-special-devices)
…....... [CHEATS] [Widescreen Codes Archive](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/ps1-widescreen-codes)
…....... [EXE] [BATCHER_0.3 – create/update your ELFs launchers automatically](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/popstarter-batcher)
…....... [DS3] [Use DualShock 3 Controller with POPStarter](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/ds34)
______________________________________________________________________________________________________________

***Need help ?***

Ask over at [PSX-Place](https://www.psx-place.com/threads/popstarter-beta-from-2019-06-05.19139/). Be sure to run POPStarter in [debug mode](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/debug-mode) before.

______________________________________________________________________________________________________________

### [**Wiki Homepage**](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/Home)
